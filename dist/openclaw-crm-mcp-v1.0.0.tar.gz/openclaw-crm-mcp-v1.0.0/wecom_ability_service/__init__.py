from __future__ import annotations

import logging
import os
from pathlib import Path

from flask import Flask

from .db import close_db, init_app as init_db_app
from .mcp_adapter import mcp_bp
from .routes import bp

DEFAULT_SECRET_KEY = "dev-secret-key-change-me"


def _has_configured_secret_key(app: Flask) -> bool:
    value = str(app.config.get("SECRET_KEY", "") or "").strip()
    return bool(value and value != DEFAULT_SECRET_KEY)


def _configure_logging(app: Flask) -> None:
    formatter = logging.Formatter("%(asctime)s %(name)s %(levelname)s %(message)s")
    if not app.logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)

    for logger_name in ["callback", "archive_sync", "contacts_sync", "wecom_api", "mcp", "questionnaire"]:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        logger.propagate = True
        if not logger.handlers:
            for handler in app.logger.handlers:
                logger.addHandler(handler)


def _log_startup_config(app: Flask) -> None:
    oauth_keys = ["WECHAT_MP_APP_ID", "WECHAT_MP_APP_SECRET", "WECHAT_MP_OAUTH_SCOPE", "SECRET_KEY"]
    snapshot_items = []
    for key in oauth_keys:
        if key == "SECRET_KEY":
            status = "set" if _has_configured_secret_key(app) else "missing"
        else:
            status = "set" if str(app.config.get(key, "") or "").strip() else "missing"
        snapshot_items.append(f"{key}={status}")
    snapshot = ", ".join(snapshot_items)
    app.logger.info("questionnaire oauth config: %s", snapshot)
    missing_required = [
        key
        for key in ["WECHAT_MP_APP_ID", "WECHAT_MP_APP_SECRET"]
        if not str(app.config.get(key, "") or "").strip()
    ]
    if not _has_configured_secret_key(app):
        missing_required.append("SECRET_KEY")
    if missing_required:
        app.logger.warning(
            "questionnaire oauth not fully configured, missing=%s; service will still start and non-oauth flows remain available",
            ",".join(missing_required),
        )
    app.logger.info(
        "questionnaire session debug api: %s",
        "enabled" if app.config.get("ENABLE_DEBUG_QUESTIONNAIRE_SESSION_API") else "disabled",
    )


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=False)
    explicit_debug_session_api = os.getenv("ENABLE_DEBUG_QUESTIONNAIRE_SESSION_API", "").strip()

    default_db_path = Path(app.root_path).parent / "data.sqlite3"
    app.config.from_mapping(
        DEBUG=os.getenv("FLASK_ENV", "").lower() == "development",
        SECRET_KEY=os.getenv("SECRET_KEY", DEFAULT_SECRET_KEY),
        APP_HOST=os.getenv("APP_HOST", "127.0.0.1"),
        APP_PORT=os.getenv("APP_PORT", "5000"),
        DATABASE_URL=os.getenv("DATABASE_URL", ""),
        DATABASE_PATH=os.getenv("DATABASE_PATH", str(default_db_path)),
        WECOM_CORP_ID=os.getenv("WECOM_CORP_ID", ""),
        WECOM_CONTACT_SECRET=os.getenv("WECOM_CONTACT_SECRET", ""),
        WECOM_SECRET=os.getenv("WECOM_SECRET", ""),
        WECOM_AGENT_ID=os.getenv("WECOM_AGENT_ID", ""),
        WECOM_API_BASE=os.getenv("WECOM_API_BASE", "https://qyapi.weixin.qq.com"),
        WECOM_ARCHIVE_SECRET=os.getenv("WECOM_ARCHIVE_SECRET", ""),
        WECOM_PRIVATE_KEY_PATH=os.getenv("WECOM_PRIVATE_KEY_PATH", "/home/ubuntu/wecom_private_key.pem"),
        WECOM_SDK_LIB_PATH=os.getenv(
            "WECOM_SDK_LIB_PATH", "/home/ubuntu/wecom-sdk/C_sdk/libWeWorkFinanceSdk_C.so"
        ),
        WECOM_DEFAULT_OWNER_USERID=os.getenv("WECOM_DEFAULT_OWNER_USERID", ""),
        WECOM_CALLBACK_TOKEN=os.getenv("WECOM_CALLBACK_TOKEN", ""),
        WECOM_CALLBACK_AES_KEY=os.getenv("WECOM_CALLBACK_AES_KEY", ""),
        WECHAT_MP_APP_ID=os.getenv("WECHAT_MP_APP_ID", ""),
        WECHAT_MP_APP_SECRET=os.getenv("WECHAT_MP_APP_SECRET", ""),
        WECHAT_MP_OAUTH_SCOPE=os.getenv("WECHAT_MP_OAUTH_SCOPE", "snsapi_base"),
        ENABLE_DEBUG_QUESTIONNAIRE_SESSION_API=(
            explicit_debug_session_api.lower() in {"1", "true", "yes"} if explicit_debug_session_api else None
        ),
        WECOM_ARCHIVE_TIMEOUT=int(os.getenv("WECOM_ARCHIVE_TIMEOUT", "15")),
        WECOM_SYNC_BATCH_SIZE=int(os.getenv("WECOM_SYNC_BATCH_SIZE", "100")),
        WECOM_SYNC_RETRY_LIMIT=int(os.getenv("WECOM_SYNC_RETRY_LIMIT", "3")),
        MCP_BEARER_TOKEN=os.getenv("MCP_BEARER_TOKEN", ""),
        ACCESS_TOKEN_CACHE_SECONDS=int(os.getenv("ACCESS_TOKEN_CACHE_SECONDS", "7000")),
        SQLITE_BUSY_TIMEOUT_MS=int(os.getenv("SQLITE_BUSY_TIMEOUT_MS", "5000")),
        SIDEBAR_THIRD_PARTY_API_URL=os.getenv("SIDEBAR_THIRD_PARTY_API_URL", ""),
        SIDEBAR_THIRD_PARTY_API_TOKEN=os.getenv("SIDEBAR_THIRD_PARTY_API_TOKEN", ""),
        SIDEBAR_THIRD_PARTY_TIMEOUT_SECONDS=int(os.getenv("SIDEBAR_THIRD_PARTY_TIMEOUT_SECONDS", "10")),
        SIDEBAR_PERSON_DETAIL_URL_TEMPLATE=os.getenv(
            "SIDEBAR_PERSON_DETAIL_URL_TEMPLATE",
            "https://www.youcangogogo.com/person/{person_id}",
        ),
        ENV_FILE_PATH=os.getenv("ENV_FILE_PATH", "/home/ubuntu/.openclaw-wecom.env"),
        CRON_SCRIPT_PATH=os.getenv(
            "CRON_SCRIPT_PATH",
            str(Path(app.root_path).parent / "scripts" / "run_incremental_archive_sync.py"),
        ),
    )

    if test_config:
        app.config.update(test_config)

    app.config.setdefault("CALLBACK_ASYNC_ENABLED", not app.testing)
    if app.config.get("ENABLE_DEBUG_QUESTIONNAIRE_SESSION_API") is None:
        app.config["ENABLE_DEBUG_QUESTIONNAIRE_SESSION_API"] = app.testing

    init_db_app(app)
    app.teardown_appcontext(close_db)
    _configure_logging(app)
    _log_startup_config(app)
    app.register_blueprint(bp)
    app.register_blueprint(mcp_bp)

    return app
